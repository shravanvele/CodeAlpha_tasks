module.exports = {
    "type": "module"
  };